package com.khunsoe.dream.ui;
import android.app.Dialog;
import android.view.*;

import com.google.android.material.button.MaterialButton;
import com.khunsoe.dream.model.PostItem;
import com.khunsoe.dream.R;

import java.util.*;
import org.json.*;

public class MainActivity extends ListActivity
{
	//links နှင့် titles အောက်ကိုထည့်ပါ။


	String[] links={
		    "https://raw.githubusercontent.com/khonsoe/Dream_3D/main/Html/Myanmar.html",
			"https://raw.githubusercontent.com/khonsoe/Dream_3D/main/Html/Shan.html",
			"https://raw.githubusercontent.com/khonsoe/Dream_3D/main/Html/Thai.html"
	};
	
	String[] titles={
			"Search",
			"Shan",
			"Thai"

	};
	
	int current=0;

	@Override
	public void _Options_Menu_Click(MenuItem item)
	{
		int id=item.getItemId();
		if (id == R.id.about) {
			final Dialog mmDialog = new Dialog(MainActivity.this, R.style.Dialog_MinWidth);
			mmDialog.setContentView(R.layout.about);
			mmDialog.setCancelable(false);
			MaterialButton close = mmDialog.findViewById(R.id.close);
			close.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					mmDialog.dismiss();
					//Toast.makeText(context, R.string.cancel, Toast.LENGTH_SHORT).show();
				}
			});
			mmDialog.show();
		}else if(id==R.id.rate){
			srue();
		}else if(id==R.id.moreapp) {
			//moreapp();
			moreApp("KHUN SOE ZAW THU");
		}else {
			if (id == R.id.mm1000)
			{
				current = 0;
			}

			if (id == R.id.shan)
			{
				current = 1;
			}

			if (id == R.id.thai)
			{
				current = 2;
			}

			refresh();
		}
	}

	public void processJson(String inputJson){
		posts = new ArrayList<>();

		String start = "<body>";
		if(inputJson.contains(start))
			inputJson=inputJson.substring(inputJson.indexOf(start)+start.length());

		String end = "</body>";
		if(inputJson.contains(end))
			inputJson=inputJson.substring(0,inputJson.indexOf(end));
		try
		{
					JSONObject obj=new JSONObject(inputJson);
					JSONArray jarr=obj.getJSONArray("am1000");
					for(int j=0;j<jarr.length();j++){
						PostItem p=new PostItem();
						p.nbs=(jarr.getJSONObject(j).getString("nbs"));
						p.nb=(jarr.getJSONObject(j).getString("nb"));
						p.nmb=(jarr.getJSONObject(j).getString("nmb"));
						p.im=(jarr.getJSONObject(j).getString("im"));

						addItem(p);
					}
		}
		catch (JSONException e)
		{
			//Toast.makeText(this,e.toString(),1).show();
		}
	}

	@Override
	public boolean useGridLayout()
	{
		return true;
	}

	@Override
	public String getFeedAddress()
	{
		setTitle(titles[current]);
		return links[current];
	}

}
