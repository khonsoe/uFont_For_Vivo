package com.khunsoe.dream.ads;

public class AdsConstants {
    public static final String appid="ca-app-pub-2550685256430558~1182318605";
    public static final String APP_OPEN ="ca-app-pub-2550685256430558/6344760346";
    public static final String INTERSTITIAL ="ca-app-pub-2550685256430558/9607603539";
}
