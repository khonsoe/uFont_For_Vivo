package com.khunsoe.dream.model;

public class PostItem
{
	//public String updated="";
	public String nbs="";
	public String nb="";
	public String nmb="";
	public String im="";
}
