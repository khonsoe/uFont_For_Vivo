package khunsoe.zawtbu;

import android.app.*;
import android.content.*;
import android.content.res.*;
import android.net.*;
import android.os.*;

import androidx.annotation.NonNull;
import androidx.core.view.*;
import androidx.appcompat.app.*;

import android.text.*;
import android.util.Log;
import android.view.*;
import android.widget.*;

import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;

import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;

import khunsoe.zawtbu.Async.TaskRunner;
import khunsoe.zawtbu.update.CheckUpdateAsyncTask;
import com.squareup.picasso.*;
import java.util.*;

import android.app.AlertDialog;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

public abstract class ListActivity extends AppCompatActivity {
	protected ListActivity() {
	}

	public abstract void processJson(String jsonString);

	public abstract boolean useGridLayout();

	public abstract String getFeedAddress();

	public abstract void _Options_Menu_Click(MenuItem item);

	final String mapp="KHUN SOE ZAW THU";
	private SwipeRefreshLayout mSwipeLayout;
	RecyclerView rv;
	FeedAdapter adapter;
	List<PostItem> posts, filteredposts;
	boolean online = true;
	Toolbar tb;
	String currentLink = "";
	final int FONT_NONE = 0;
	int currentFont = FONT_NONE;

	DrawerLayout mDrawerLayout;
	private ActionBarDrawerToggle mDrawerToggle;
	private NavigationView navigationView;

	private final boolean euConsent= true;
	private String TAG;
	private InterstitialAd mInterstitialAd;

	TextView tvv;

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_list);

		tb = (Toolbar) findViewById(R.id.kr_toolbar);
		setSupportActionBar(tb);

		new CheckUpdateAsyncTask(this, "https://raw.githubusercontent.com/khonsoe/updatevivo/master/updatevivo.json");


		navigationView = (NavigationView) findViewById(R.id.ngv);
		mDrawerLayout = (DrawerLayout) findViewById(R.id.kr_drawer_layout);
		mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, 0, 0);
		//mDrawerLayout.setDrawerListener(mDrawerToggle);
		mDrawerLayout.addDrawerListener(mDrawerToggle);
		if (getSupportActionBar()!=null)
			getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		setupNV();

		assert navigationView != null;
		navigationView.setItemIconTintList(null);

		navigationView.setNavigationItemSelectedListener(menuItem -> {
			menuItem.setChecked(true);
			mDrawerLayout.closeDrawers();
			//_MenuItem_Click(menuItem.getItemId());
			_Options_Menu_Click(menuItem);
			return true;
		});
		FloatingActionButton fab = findViewById(R.id.fab);
		fab.setOnClickListener(view -> {
			Intent intent = new Intent("android.intent.action.SEND");
			intent.setType("text/plain");
			intent.putExtra("android.intent.extra.TEXT", "Download Free PlayStore Vivo Theme\n\nhttps://play.google.com/store/apps/details?id=khunsoe.zawtbu\n\nThanks for your encouragement😍");
			startActivity(new Intent(Intent.createChooser(intent, "uFont for Vivo")));
		});

		MobileAds.initialize(this, initializationStatus -> {
			if (euConsent) {
				AdpShow();
			} else {
				AdpShowError();

			}
		});
	}
	private void AdpShow() {
		AdRequest adRequest = new AdRequest.Builder().build();
		AdInterstitialAd(adRequest);
	}
	private void AdpShowError() {
		Bundle networkExtrasBundle = new Bundle();
		networkExtrasBundle.putInt("rdp", 1);
		AdRequest adRequest = new AdRequest.Builder()
				.addNetworkExtrasBundle(AdMobAdapter.class, networkExtrasBundle)
				.build();
		AdInterstitialAd(adRequest);
	}
	private void AdInterstitialAd(AdRequest adRequest) {
		InterstitialAd.load(this, Ads.ad, adRequest, new InterstitialAdLoadCallback() {

			@Override
			public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
				// The mInterstitialAd reference will be null until
				// an ad is loaded.
				mInterstitialAd = interstitialAd;
				Log.i(TAG, "onAdLoaded");
				mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
					@Override
					public void onAdDismissedFullScreenContent() {
						// Called when fullscreen content is dismissed.
						Log.d("TAG", "The ad was dismissed.");
						if (euConsent) {
							AdpShow();
						} else {
							AdpShowError();
						}
					}

					@Override
					public void onAdFailedToShowFullScreenContent(AdError adError) {
						// Called when fullscreen content failed to show.
						Log.d("TAG", "The ad failed to show.");
					}

					@Override
					public void onAdShowedFullScreenContent() {
						// Called when fullscreen content is shown.
						// Make sure to set your reference to null so you don't
						// show it a second time.
						mInterstitialAd = null;
						Log.d("TAG", "The ad was shown.");
					}
				});
			}

			@Override
			public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
				// Handle the error
				Log.i(TAG, loadAdError.getMessage());
				mInterstitialAd = null;
			}
		});
		mSwipeLayout = (SwipeRefreshLayout) findViewById(R.id.swipeRefreshLayout);
		mSwipeLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
			@Override
			public void onRefresh() {
				if (isOnline())
					refresh();
				else {
					mSwipeLayout.setRefreshing(false);
					//net error
					netError();
				}
			}
		});
		mSwipeLayout.setColorSchemeResources(
				R.color.refresh_progress_1,
				R.color.refresh_progress_2,
				R.color.refresh_progress_3);

		posts = new ArrayList<PostItem>();
		filteredposts = new ArrayList<PostItem>();
		rv = (RecyclerView) findViewById(R.id.revlist);
		if (useGridLayout()) {
			rv.setLayoutManager(new GridLayoutManager(this, 1));
		} else {
			rv.setLayoutManager(new LinearLayoutManager(this));
		}
		SharedPreferences sharedPreferences = getSharedPreferences("MyData", Context.MODE_PRIVATE);
		currentFont = sharedPreferences.getInt("font_main", 0);
		refresh();
	}

	private void setupNV() {
		navigationView.getMenu().clear();
		navigationView.inflateMenu(R.menu.navigation_menu);
	}

	protected void onPostCreate(Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		mDrawerToggle.syncState();
	}

	@Override
	public void onConfigurationChanged(@NonNull Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		mDrawerToggle.onConfigurationChanged(newConfig);
	}

	public void netError() {
		//Toast.makeText(getApplicationContext(),"No internet connection",Toast.LENGTH_SHORT).show();
		//ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		//NetworkInfo ni = cm.getActiveNetworkInfo();
		//if (ni == null) {
		final ProgressDialog pDialog = new ProgressDialog(ListActivity.this);
		pDialog.setIcon(R.drawable.net_error);
		pDialog.setProgress(ProgressDialog.STYLE_SPINNER);
		pDialog.setTitle("Internet Error");
		pDialog.setMessage("No Internet connection");
		pDialog.setCancelable(false);
		pDialog.setButton("TryAgain", (dialog, which) -> refresh());
		//No.Button
		pDialog.setButton2("Cancel", (dialog, which) -> pDialog.dismiss());
		pDialog.show();
	}

	public void refresh() {
		//adapter.reset();
		currentLink = getFeedAddress();
		tb.collapseActionView();
		if (isOnline()) {
			online = true;
			download(currentLink);
		} else {
			online = false;
			//netError
			netError();
			//Toast.makeText(getApplicationContext(),"No internet connection",Toast.LENGTH_SHORT).show();

			try {
				processJson(getFromPrefs(currentLink));
				adapter = new FeedAdapter();
				rv.setAdapter(adapter);
			} catch (Exception e) {
				Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();
			}
		}
	}

	public void saveToPrefs(String result) {
		SharedPreferences sharedPreferences = getSharedPreferences("MyData", Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = sharedPreferences.edit();
		editor.putString(currentLink, result);
		editor.apply();
	}

	public String getFromPrefs(String key) {
		SharedPreferences sharedPreferences = getSharedPreferences("MyData", Context.MODE_PRIVATE);
		return sharedPreferences.getString(currentLink, "");
	}

	private void download(String url){
		mSwipeLayout.setRefreshing(true);
		new TaskRunner().executeAsync(() -> Down.download(url), new TaskRunner.Callback<String>() {
			@Override
			public void onTaskCompleted(String result) {
				processJson(result);
				saveToPrefs(result);
				mSwipeLayout.setRefreshing(false);
				adapter = new FeedAdapter();
				rv.setAdapter(adapter);
			}

			@Override
			public void onTaskFailure(String error) {
				Toast.makeText(ListActivity.this, error, Toast.LENGTH_SHORT).show();
			}
		});
	}

	protected boolean isOnline() {
		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo netInfo = cm.getActiveNetworkInfo();
		return netInfo != null && netInfo.isConnectedOrConnecting();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main_menu, menu);
		MenuItem myActionMenuItem = menu.findItem(R.id.menu_search);
		SearchView sv = (SearchView) myActionMenuItem.getActionView();
		sv.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
			@Override
			public boolean onQueryTextSubmit(String p1) {
				return false;
			}

			@Override
			public boolean onQueryTextChange(String p1) {
				adapter.filter(p1.toString());
				return false;
			}
		});
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int id = item.getItemId();
		if (id == android.R.id.home) {
			mDrawerLayout.openDrawer(GravityCompat.START);
			return true;
		} else {
			_Options_Menu_Click(item);
		}
		return super.onOptionsItemSelected(item);
	}

	public void addItem(PostItem item) {
		posts.add(item);
	}

	public class FeedAdapter extends RecyclerView.Adapter<FeedAdapter.ViewHolder> {
		@NonNull
		@Override
		public FeedAdapter.ViewHolder onCreateViewHolder(ViewGroup p1, int p2) {
			View v = getLayoutInflater().inflate(R.layout.list_adapter, p1, false);
			return new ViewHolder(v);
		}

		public void filter(String charText) {
			charText = charText.toLowerCase();
			filteredposts.clear();
			if (charText.length() == 0) {
				filteredposts.addAll(posts);
			} else {
				for (PostItem pi : posts) {
					if (pi.title.toLowerCase().contains(charText)) {
						filteredposts.add(pi);
					}
				}
			}
			notifyDataSetChanged();
		}

		@Override
		public int getItemCount() {
			return filteredposts.size();
		}

		@Override
		public void onBindViewHolder(FeedAdapter.ViewHolder p1, int p2) {
			if ((filteredposts.get(p2).thumbnailUrl.length() > 0) && (online)) {
				Picasso
						.with(getApplicationContext())
						.load(Html.fromHtml(filteredposts.get(p2).thumbnailUrl).toString())
						.into(p1.imv);
			} else {
				p1.imv.setImageResource(R.drawable.ic_refresh);
			}
			p1.txtv.setText(filteredposts.get(p2).title);
			p1.nnee.setText(filteredposts.get(p2).desc);
		}

		public PostItem getItem(int pos) {
			return filteredposts.get(pos);
		}

		public void reset() {
			posts.clear();
			filteredposts.clear();
			notifyDataSetChanged();
		}

		public FeedAdapter() {
			super();
			filteredposts = new ArrayList<>();
			filteredposts.addAll(posts);
		}


		public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
			ImageView imv;
			TextView txtv,nnee;

			@Override
			public void onClick(View view) {
				Intent i = new Intent(ListActivity.this, FontActivity.class);
				PostItem pi = filteredposts.get(getAdapterPosition());
				i.putExtra("title", pi.title);
				i.putExtra("link", pi.link);
				i.putExtra("desc", pi.desc);
				i.putExtra("image", pi.thumbnailUrl);
				startActivity(i);
				//showAD();
			}

			public ViewHolder(View view) {
				super(view);
				imv = view.findViewById(R.id.item_image);
				txtv = view.findViewById(R.id.ItemText);
				nnee = view.findViewById(R.id.nn);
				view.setOnClickListener(this);
			}
		}
	}

	public void MsgBox(String title, String msg) {
		AlertDialog alertDialog = new AlertDialog.Builder(this).create();
		alertDialog.setIcon(R.drawable.ic_help);
		alertDialog.setTitle(title);
		alertDialog.setMessage(msg);
		alertDialog.setButton("OK", (dialog, which) -> {
			dialog.dismiss();
			//showAD();
		});
		alertDialog.show();

	}

	public void showAD() {
		if (mInterstitialAd != null) {
			mInterstitialAd.show(ListActivity.this);
		} else {
			Log.d("TAG", "The interstitial ad wasn't ready yet.");
		}
	}

	@Override
	public void onBackPressed() {
			AlertDialog alert=new AlertDialog.Builder (this).create();
			alert.setIcon(R.drawable.ic_launcher);
			alert.setTitle("Notice!");
			alert.setMessage("Do you want to Exit ?");
			//alert.setView(getLayoutInflater().inflate(R.layout.img,null));
			//Yes Button
			alert.setButton("Exit",new DialogInterface.OnClickListener(){
				@Override
				public void onClick(DialogInterface dialog,int which)
				{
					//showAD();
					ListActivity.this.finish();

				}});
			//No.Button
			alert.setButton2("CANCEL",new DialogInterface.OnClickListener(){
				@Override
				public void onClick(DialogInterface dialog,int which){

					dialog. dismiss();

				}

			});

			alert.setButton(AlertDialog.BUTTON_NEUTRAL, "Rate App", new DialogInterface.OnClickListener(){
				@Override
				public void onClick(DialogInterface p1, int p2)
				{
					//showAD();
					ratePlayStore();
				}});
			alert.show();

			//  super.onBackPressed();
		}
	private void ratePlayStore(){
		AlertDialog alert=new AlertDialog.Builder (this).create();
		alert.setIcon(R.drawable.ic_launcher);
		alert.setTitle("Help Us");
		alert.setCanceledOnTouchOutside(false);
		alert.setCancelable(false);
		alert.setView(getLayoutInflater().inflate(R.layout.rate,null));
		//Yes Button
		alert.setButton("Rate Now",new DialogInterface.OnClickListener(){
			@Override
			public void onClick(DialogInterface dialog,int which){
				rate();

			}});
		//No.Button
		alert.setButton2("No,Thanks",new DialogInterface.OnClickListener(){
			@Override
			public void onClick(DialogInterface dialog,int which){
				dialog.dismiss();

			}
		});
		alert.show();
	}
	public void rate(){
		try {
			startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getPackageName())));
		} catch (android.content.ActivityNotFoundException anfe) {
			startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName())));
		}

	}
	public void moreapp(){
		try {
			startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=pub:"+ mapp)));
		} catch (android.content.ActivityNotFoundException anfe) {
			startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/search?q=pub:"+ mapp)));
		}

	}
}