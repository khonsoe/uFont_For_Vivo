package khunsoe.zawtbu;


import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.documentfile.provider.DocumentFile;

import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.squareup.picasso.Picasso;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.Locale;
import java.util.Objects;
import java.util.concurrent.Callable;
import khunsoe.zawtbu.Async.TaskRunner;
import khunsoe.zawtbu.Service.VivouFontService;
import khunsoe.zawtbu.Utils.VivoFontInstaller;


public class FontActivity extends AppCompatActivity {
    TextView txtv;
    ImageView imv;
    String title, link, image, desc;
    androidx.appcompat.widget.Toolbar tb;

    ProgressDialog progressDialog;

    private final boolean euConsent= true;
    private AdRequest adRequest;
    private InterstitialAd mInterstitialAd;

    //ttf file path
    String downloadedITZ = null;
    VivoFontInstaller vivoFontInstaller;

    String target;
    String watch;
    boolean after60;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_font);
        vivoFontInstaller = new VivoFontInstaller(FontActivity.this);
        tb = findViewById(R.id.kr_toolbar2);
        progressDialog = new ProgressDialog(this);
        setSupportActionBar(tb);
        if (getSupportActionBar()!=null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        MobileAds.initialize(this, initializationStatus -> {
            if (euConsent){
                AdpShow();
            }else {
                AdpShowError();

            }
        });
        AdView mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

    }

    public void showAD(){
        if (mInterstitialAd != null) {
            mInterstitialAd.show(FontActivity.this);
        } else {
            Log.d("TAG", "The interstitial ad wasn't ready yet.");
        }
    }

    private void AdpShow() {
        AdRequest adRequest = new AdRequest.Builder().build();
        AdInterstitialAd(adRequest);
    }
    private void AdpShowError() {
        Bundle networkExtrasBundle = new Bundle();
        networkExtrasBundle.putInt("rdp", 1);
        AdRequest adRequest = new AdRequest.Builder()
                .addNetworkExtrasBundle(AdMobAdapter.class, networkExtrasBundle)
                .build();
        AdInterstitialAd(adRequest);
    }
    private void AdInterstitialAd(AdRequest adRequest) {
        InterstitialAd.load(this, Ads.ad, adRequest, new InterstitialAdLoadCallback() {

            @Override
            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                // The mInterstitialAd reference will be null until
                // an ad is loaded.
                mInterstitialAd = interstitialAd;
                mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override
                    public void onAdDismissedFullScreenContent() {
                        // Called when fullscreen content is dismissed.
                        Log.d("TAG", "The ad was dismissed.");
                        if (euConsent) {
                            AdpShow();
                        } else {
                            AdpShowError();
                        }
                    }

                    @Override
                    public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                        // Called when fullscreen content failed to show.
                        Log.d("TAG", "The ad failed to show.");
                    }

                    @Override
                    public void onAdShowedFullScreenContent() {
                        // Called when fullscreen content is shown.
                        // Make sure to set your reference to null so you don't
                        // show it a second time.
                        mInterstitialAd = null;
                        Log.d("TAG", "The ad was shown.");
                    }
                });
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                // Handle the error
                mInterstitialAd = null;
            }
        });

        MobileAds.initialize(this, initializationStatus -> {});


    
        txtv = (TextView) findViewById(R.id.textvvi);
        imv = (ImageView) findViewById(R.id.imvvi);
        Intent intent = getIntent();
        title = intent.getStringExtra("title");
        link = intent.getStringExtra("link");
        image = intent.getStringExtra("image");
        desc = intent.getStringExtra("desc");
        Log.e("LINK: ", link);
        setTitle(title);
        Picasso.with(this)
                .load(image)
                .into(imv);
        txtv.setText(String.format("%s\n\n%s", title,desc));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            //showAD();
        }
        return super.onOptionsItemSelected(item);
    }


    public void downloadClick(View v) {
        //downloadFromUrl();
        download(link);
        //showAD();
    }

    private DocumentFile getDocumentFile(){
        DocumentFile documentFile = null;
        if (Constants.isAfterAndroid10()){
            Uri uri = SAFConstants.loadSavedDirectory(this,Constants.ROOT_DIR_NAME);
            if (uri != null){
                documentFile = DocumentFile.fromTreeUri(this,uri);
                for (String k:Constants.DWD_FONT_PATH.split("/")) {
                    if (!k.equalsIgnoreCase(Constants.ROOT_DIR_NAME))
                        documentFile = SAFConstants.findFolder(documentFile, k);
                }
            }
        }
        return documentFile;
    }

    private void download(String link){
        Dialog mDialog;
        TextView text;
        TextView pp;
        ProgressBar progressBar;
        Button cancel;
        mDialog = new Dialog(this, R.style.Theme_AppCompat_Translucent);
        mDialog.setContentView(R.layout.custom_dialog);
        text = mDialog.findViewById(R.id.ttt);
        progressBar = mDialog.findViewById(R.id.progressBar3);
        pp = mDialog.findViewById(R.id.pp);
        pp.setText("0%");
        progressBar.setMax(100);
        TextView text2 = mDialog.findViewById(R.id.title);
        text2.setText(R.string.please_wait);
        mDialog.setCancelable(false);
        mDialog.show();
        cancel=mDialog.findViewById(R.id.cl);
        cancel.setOnClickListener(v -> {
            mDialog.dismiss();
            mDialog.cancel();
            Toast.makeText(this,"Cancel", Toast.LENGTH_SHORT).show();
        });

        new TaskRunner().executeAsync(new Callable<String>() {
            private void doProgress(String s, String prog) {
               runOnUiThread(() -> {
                   progressBar.setProgress(Integer.parseInt(prog));
                   pp.setText(prog + "%");
                   text.setText(s);
               });
            }

            @Override
            public String call() throws Exception {
                int count;
                URL url = new URL(link);
                URLConnection conexion = url.openConnection();
                conexion.connect();
                int lenghtOfFile = conexion.getContentLength();

                downloadedITZ = new File(Constants.DEFAULT_DWD_PATH,title + VivoFontInstaller.OWN_EXTENSION).getPath();

                InputStream input = new BufferedInputStream(url.openStream());
                OutputStream output = null;
                if (Constants.isAfterAndroid10()){
                    DocumentFile documentFile = getDocumentFile();
                    if (documentFile!=null) {
                        documentFile = documentFile.createFile("*/*", title + VivoFontInstaller.OWN_EXTENSION);
                        output = getContentResolver().openOutputStream(Objects.requireNonNull(documentFile).getUri());
                    }
                }else {
                    File pngDir = Constants.DEFAULT_DWD_PATH;
                    if (!pngDir.exists())
                        pngDir.mkdirs();
                    File file = new File(pngDir, title + VivoFontInstaller.OWN_EXTENSION);
                    output = new FileOutputStream(file);
                }

                byte[] data = new byte[1024];
                long total = 0;
                while ((count = input.read(data)) != -1) {
                    total += count;
                    String prog = ("" + (int) ((total * 100) / lenghtOfFile));
                    doProgress(formatBytes(total) + "/" + formatBytes(lenghtOfFile), prog);
                    output.write(data, 0, count);
                }
                output.flush();
                output.close();
                input.close();
                return "ok";
            }
        }, new TaskRunner.Callback<String>() {
            @Override
            public void onTaskCompleted(String result) {
                if (result.equals("ok")) {
                    vivoFontInstaller.OnFinishedListener(new VivoFontInstaller.OnDone() {
                        @Override
                        public void onCompleted(String targetM, String watchM, boolean after60M) {
                            //showAD();
                            downloadDone();
                            target = targetM;
                            watch = watchM;
                            after60 = after60M;
                            mDialog.dismiss();
                        }

                        @Override
                        public void onError() {
                            mDialog.dismiss();
                            Toast.makeText(FontActivity.this, "ERROR!", Toast.LENGTH_SHORT).show();
                        }

                        @Override
                        public void noMore() {
                            mDialog.dismiss();
                            prepareUpdateKey();
                        }
                    });
                    vivoFontInstaller.install(downloadedITZ);
                    Log.e("onPostExecute: ", "ok");
                } else {
                    Log.e("onPostExecute: ", "error");
                    mDialog.dismiss();
                }
            }

            @Override
            public void onTaskFailure(String error) {
                Toast.makeText(FontActivity.this, error, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean isOnline() {
        Runtime runtime = Runtime.getRuntime();
        try {
            Process ipProcess = runtime.exec("/system/bin/ping -c 1 8.8.8.8");
            int     exitValue = ipProcess.waitFor();
            return (exitValue == 0);
        }
        catch (IOException e)          { e.printStackTrace(); }
        catch (InterruptedException e) { e.printStackTrace(); }
        return false;
    }

    private void prepareUpdateKey() {
        if (isOnline()){
            new androidx.appcompat.app.AlertDialog.Builder(this)
                    .setTitle("Attention!")
                    .setMessage("You need to update database")
                    .setPositiveButton("Update database", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            updateKey();
                        }
                    })
                    .setCancelable(false)
                    .show();
        }else {
            new androidx.appcompat.app.AlertDialog.Builder(FontActivity.this)
                    .setTitle("No internet connection!")
                    .setMessage("Please connect to wifi or turn on internet connection.")
                    .setPositiveButton("Try again", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            prepareUpdateKey();
                        }
                    })
                    .setNegativeButton("Close", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            finish();
                        }
                    })
                    .show();
        }
    }

    private void updateKey() {
        if (isOnline()){
            progressDialog.show();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    String json = Down.download("https://raw.githubusercontent.com/khonsoe/uFont_For_Vivo/main/UpdateKey/out.json");
                    if (!json.isEmpty()) {
                        VivoFontInstaller.addData(json,FontActivity.this);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(FontActivity.this, "Updated!", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                    progressDialog.dismiss();
                }
            }).start();
        }else prepareUpdateKey();
    }

    private void downloadDone(){
        new AlertDialog.Builder(this)
                .setTitle("Done")
                .setMessage(R.string.Install_font_uccessfully)
                .setNegativeButton("OK", (dialogInterface, i) -> showAD())
                .setPositiveButton(R.string.chang_font, (dialogInterface, i) -> {
                    showAD();
                    changeFont();
                })
                .show();
    }
    public static String formatBytes(long bytes) {
        Locale locale = Locale.getDefault();
        if (bytes < 1024) {
            return String.format(locale, "%d B", bytes);
        } else if (bytes < 1024 * 1024) {
            return String.format(locale, "%.2f KB", bytes / 1024d);
        } else {
            return String.format(locale, "%.2f MB", bytes / 1024d / 1024d);

        }

    }
    public void changeTheme(View view){
        try{
           changeFont();

        }catch (Exception e){
            ChBox("Hi",getString(R.string.download_first));
            //Toast.makeText(this, download_first, Toast.LENGTH_SHORT).show();
            //showAD();
        }
    }
    public void ChBox(String title, String msg) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(msg)
                .setPositiveButton("OK", (dialog, which) -> {
                    dialog.dismiss();
                    //showAD();
                })
                .setNegativeButton(getString(R.string.download), (dialog, which) -> {
                    download(link);
                    //showAD();
                })
                .show();
    }

    private void changeFont() {
        if (after60) {
            Intent intent = new Intent(FontActivity.this, VivouFontService.class);
            intent.setAction(VivouFontService.ACTION_START_FOREGROUND_SERVICE);
            intent.putExtra(VivouFontService.TARGET_FILE, target);
            intent.putExtra(VivouFontService.WATCHING_FILE, watch);
            intent.putExtra(VivouFontService.NAME, title);
            startService(intent);
        }
        vivoFontInstaller.changeFont();

    }
}