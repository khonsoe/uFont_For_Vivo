package khunsoe.zawtbu;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.text.*;
import android.view.*;

import java.util.*;
import org.json.*;

public class MainActivity extends ListActivity
{
	final String mapp="KHUN SOE ZAW THU";

	String[] links={
			"https://raw.githubusercontent.com/khonsoe/uFont_For_Vivo/main/Html/English.html",
			"https://raw.githubusercontent.com/khonsoe/uFont_For_Vivo/main/Html/Arabic.html",
			"https://raw.githubusercontent.com/khonsoe/uFont_For_Vivo/main/Html/Chinese.html",
			"https://raw.githubusercontent.com/khonsoe/uFont_For_Vivo/main/Html/Indian.html",
			"https://raw.githubusercontent.com/khonsoe/uFont_For_Vivo/main/Html/Japanese.html",
			"https://raw.githubusercontent.com/khonsoe/uFont_For_Vivo/main/Html/Khmer.html",
			"https://raw.githubusercontent.com/khonsoe/uFont_For_Vivo/main/Html/Korean.html",
			"https://raw.githubusercontent.com/khonsoe/uFont_For_Vivo/main/Html/Lao.html",
			"https://raw.githubusercontent.com/khonsoe/uFont_For_Vivo/main/Html/Myanmar.html",
			"https://raw.githubusercontent.com/khonsoe/uFont_For_Vivo/main/Html/PaOh.html",
			"https://raw.githubusercontent.com/khonsoe/uFont_For_Vivo/main/Html/Russian.html",
			"https://raw.githubusercontent.com/khonsoe/uFont_For_Vivo/main/Html/Shan.html",
			"https://raw.githubusercontent.com/khonsoe/uFont_For_Vivo/main/Html/TaiTham.html",
			"https://raw.githubusercontent.com/khonsoe/uFont_For_Vivo/main/Html/Thai.html",
			"https://raw.githubusercontent.com/khonsoe/uFont_For_Vivo/main/Html/Vietnamese.html",
			"https://raw.githubusercontent.com/khonsoe/uFont_For_Vivo/main/Html/Color.html",
			"https://raw.githubusercontent.com/khonsoe/uFont_For_Vivo/main/Html/TitleFonts.html"
	};

	String[] titles={
			"English Fonts",
			"Arabic Fonts",
			"Chinese Fonts",
			"Indian Fonts",
			"Japanese Fonts",
			"Khmer Fonts",
			"Korean Fonts",
			"Lao Fonts",
			"Myanmar Fonts",
			"PaOh Fonts",
			"Russian Fonts",
			"Shan Fonts",
			"Tai Tham Fonts",
			"Thai Fonts",
			"Vietnamese Font",
			"Color Fonts",
			"Title fonts"
	};
	
	int current=0;

	@Override
	public void _Options_Menu_Click(MenuItem item)
	{
		int id=item.getItemId();
		if (id == R.id.about)
		{
			View view = getLayoutInflater().inflate(R.layout.about,null);
			AlertDialog.Builder builder = new AlertDialog.Builder(this)
					.setView(view)
					.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which){
							dialog. dismiss();

						}
					});
			AlertDialog dialog =builder.create();
			dialog.show();

		}else if(id==R.id.more_app){
			moreapp();

		}else if(id==R.id.rate_app) {
			rate();

	    }else if(id==R.id.help) {
			MsgBox("Help",getString(R.string.help));
		//showADV();

		}
		else {
			if (id == R.id.en_font)
			{
				current = 0;
			}
			else if (id == R.id.ar_font)
			{
				current = 1;
			}
			else if (id == R.id.chan_font)
			{
				current = 2;
			}
			else if (id == R.id.indian_font)
			{
				current = 3;
			}
			else if (id == R.id.ja_font)
			{
				current = 4;
			}
			else if (id == R.id.khmer_font)
			{
				current = 5;
			}
			else if (id == R.id.korea_font)
			{
				current = 6;
			}
			else if (id == R.id.lao_font)
			{
				current = 7;
			}
			else if (id == R.id.mm_font)
			{
				current = 8;
			}
			else if (id == R.id.pao_font)
			{
				current = 9;
			}
			else if (id == R.id.russia_font)
			{
				current = 10;
			}
			else if (id == R.id.shan_font)
			{
				current = 11;
			}
			else if (id == R.id.tai_font)
			{
				current = 12;
			}
			else if (id == R.id.th_font)
			{
				current = 13;
			}
			else if (id == R.id.vietnam_font)
			{
				current = 14;
			}
			else if (id == R.id.color_font)
			{
				current = 15;
			}
			else if (id == R.id.titf_font)
			{
				current = 16;
			}
			refresh();
		}
	}
	
	public void processJson(String inputJson){
		posts = new ArrayList<PostItem>();
		String input="";
		switch(currentFont){
			default:
				input=inputJson;
				break;
		}
		input=Html.fromHtml(input).toString();
		if(input.indexOf("<body>")>=0)
			input=input.substring(input.indexOf("<body>")+17);
		if(input.indexOf("</body>")>=0)
			input=input.substring(0,input.indexOf("</body>"));
		try
		{
			
					JSONObject obj=new JSONObject(input);
					JSONArray jarr=obj.getJSONArray("themes");
					for(int j=0;j<jarr.length();j++){
						PostItem p=new PostItem();
						p.title=(jarr.getJSONObject(j).getString("title"));
						p.link=(jarr.getJSONObject(j).getString("link"));
						p.thumbnailUrl=(jarr.getJSONObject(j).getString("image"));
						p.desc=(jarr.getJSONObject(j).getString("desc"));
						addItem(p);
					}
		}
		catch (JSONException e)
		{
			//Toast.makeText(this,e.toString(),1).show();
		}
	}

	@Override
	public boolean useGridLayout()
	{
		return true;
	}

	@Override
	public String getFeedAddress()
	{
		setTitle(titles[current]);
		return links[current];
	}

	public void rate(){
		try {
			startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getPackageName())));
		} catch (android.content.ActivityNotFoundException anfe) {
			startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName())));
		}

	}
	public void moreapp(){
		try {
			startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=pub:"+ mapp)));
		} catch (android.content.ActivityNotFoundException anfe) {
			startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/search?q=pub:"+ mapp)));
		}

	}

}
