package khunsoe.zawtbu.Utils;

import android.content.Context;
import android.content.res.AssetManager;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

public class VivoUtils {
    private static String SOURCE_FOLDER;

    public static boolean assets2SD(Context context, String In, String Out) {
        AssetManager assetManager = context.getAssets();
        InputStream in = null;
        OutputStream out = null;
        try {
            try {
                in = assetManager.open(In);
            } catch (IOException e) {
                e.printStackTrace();
            }
            out = new FileOutputStream(Out);
            byte[] buffer = new byte[1024];
            int read;
            assert in != null;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }
            in.close();
            out.flush();
            out.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        File file = new File(Out);
        return file.exists();
    }

    public static boolean createDirectory(String path){
        File n = new File(path);
        boolean check = false;
        if (!n.exists()){
            check = n.mkdirs();
        }else{
            check = true;
        }
        return check;
    }

    public static boolean deleteDirectory(String path) {
        return deleteDirectoryImpl(path);
    }

    private static boolean deleteDirectoryImpl(String path) {
        File directory = new File(path);

        // If the directory exists then delete
        if (directory.exists()) {
            File[] files = directory.listFiles();
            if (files == null) {
                return true;
            }
            // Run on all sub files and folders and delete them
            for (File file : files) {
                if (file.isDirectory()) {
                    deleteDirectoryImpl(file.getAbsolutePath());
                } else {
                    final File to = new File(file.getAbsolutePath() + System.currentTimeMillis());
                    file.renameTo(to);
                    to.delete();
                }
            }
        }
        final File to = new File(directory.getAbsolutePath() + System.currentTimeMillis());
        directory.renameTo(to);
        return to.delete();
    }

    public static boolean unZip(String zipFile, String targetPath)
    {
        if ((zipFile == null) || (zipFile.equals(""))) {
            System.out.println("Invalid source file");
            return false;
        }
        System.out.println("Zip file extracted!");
        return unzip(zipFile, targetPath);
    }

    public static boolean deleteFile(String path){
        File file = new File(path);
        if (file.exists()) {
            final File to = new File(file.getAbsolutePath() + System.currentTimeMillis());
            file.renameTo(to);
            return to.delete();
        }
        return false;
    }

    private static boolean unzip(String zipFile, String targetPath){
        try {
            File fSourceZip = new File(zipFile);
            File temp = new File(targetPath);
            temp.mkdir();
            ZipFile zFile = new ZipFile(fSourceZip);
            Enumeration e = zFile.entries();
            while (e.hasMoreElements()) {
                ZipEntry entry = (ZipEntry)e.nextElement();
                File destinationFilePath = new File(targetPath, entry.getName());
                String canonicalPath = destinationFilePath.getCanonicalPath();
                if (!canonicalPath.startsWith(targetPath)) {
                    System.out.println("SecurityException");
                }else {
                    destinationFilePath.getParentFile().mkdirs();
                    if (!entry.isDirectory()) {
                        BufferedInputStream bis = new BufferedInputStream(zFile.getInputStream(entry));

                        byte[] buffer = new byte[1024];
                        FileOutputStream fos = new FileOutputStream(destinationFilePath);
                        BufferedOutputStream bos = new BufferedOutputStream(fos, 1024);
                        int b;
                        while ((b = bis.read(buffer, 0, 1024)) != -1) {
                            bos.write(buffer, 0, b);
                        }
                        bos.flush();
                        bos.close();
                        bis.close();
                    }
                }
            }
        }
        catch (IOException ioe) {
            System.out.println("IOError :" + ioe);
            return false;
        }
        return true;
    }

    public static boolean ZipDirectory(String sourceDir, String zipFile) {
        SOURCE_FOLDER = sourceDir;
        try {
            boolean wasOK = false;
            FileOutputStream fout = new FileOutputStream(zipFile);
            ZipOutputStream zout = new ZipOutputStream(fout);
            File fileSource = new File(sourceDir);
            wasOK = addDirectory(zout, fileSource, true);
            zout.close();
            System.out.println("Zip file has been created!");
            return wasOK;
        }
        catch (IOException ioe) {
            System.out.println("IOException :" + ioe); }
        return false;
    }

    private static String generateZipEntry(String file) {
        return file.substring(SOURCE_FOLDER.length() , file.length());
    }

    private static boolean addDirectory(ZipOutputStream zout, File fileSource, boolean isRoot)
    {
        boolean wasOK = false;
        File[] files = fileSource.listFiles();
        System.out.println("Adding directory " + fileSource.getName());
        for (int i = 0; i < files.length; i++) {
            if (files[i].isDirectory()) {
                wasOK = addDirectory(zout, files[i], false);
                if (!wasOK) {
                    return false;
                }
            }
            else {
                try {
                    System.out.println("Adding file " + files[i].getAbsolutePath());
                    byte[] buffer = new byte['Ѐ'];
                    FileInputStream fin = new FileInputStream(files[i].getAbsoluteFile());
                    if (isRoot) {
                        zout.putNextEntry(new ZipEntry(generateZipEntry(files[i].getAbsoluteFile().toString())));
                    } else {
                        zout.putNextEntry(new ZipEntry(generateZipEntry(files[i].getAbsoluteFile().toString())));
                    }
                    int length;
                    while ((length = fin.read(buffer)) > 0) {
                        zout.write(buffer, 0, length);
                    }
                    zout.closeEntry();
                    fin.close();
                }
                catch (IOException ioe) {
                    System.out.println("IOException :" + ioe);
                    return false;
                }
            }
        }
        return true;
    }

    public static void writeTextFile(String path, String texts){
        try{
            FileWriter writer = new FileWriter(path);
            writer.append(texts);
            writer.flush();
            writer.close();

        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
