package khunsoe.zawtbu.Utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public final class MD5Utils {
    private static final char[] f19680a = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};

    private static String calcMD5(InputStream inputStream) throws NoSuchAlgorithmException, IOException {
        MessageDigest instance = MessageDigest.getInstance("MD5");
        byte[] bArr = new byte[1024];
        while (true) {
            int read = inputStream.read(bArr);
            if (read != -1) {
                instance.update(bArr, 0, read);
            } else {
                break;
            }
        }
        inputStream.close();
        return byte2String(instance.digest());
    }

    public static String getMD5(File file){
        try {
            return calcMD5(new FileInputStream(file));
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private static String byte2String(byte[] bArr) {
        StringBuilder sb = new StringBuilder(bArr.length * 2);
        for (int i = 0; i < bArr.length; i++) {
            sb.append(f19680a[(bArr[i] & 240) >>> 4]);
            sb.append(f19680a[bArr[i] & 15]);
        }
        return sb.toString();
    }
}

