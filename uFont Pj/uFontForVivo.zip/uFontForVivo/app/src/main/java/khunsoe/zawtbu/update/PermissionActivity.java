package khunsoe.zawtbu.update;


import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.storage.StorageManager;
import android.provider.DocumentsContract;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import java.io.File;

import khunsoe.zawtbu.Constants;
import khunsoe.zawtbu.R;
import khunsoe.zawtbu.SAFConstants;
import khunsoe.zawtbu.ScreenKr;


public class PermissionActivity extends AppCompatActivity {
    private ActivityResultLauncher<String> permissionResult;
    private ActivityResultLauncher<Intent> safResult;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        if (Constants.isAfterAndroid10()){
            safResult = registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                            String path = result.getData().getData().getPath().split(":")[1];
                            if (path.equals(Constants.ROOT_DIR_NAME)) {
                                SAFConstants.saveDirectory(result.getData().getData(),this,Constants.ROOT_DIR_NAME);
                            } else {
                                new AlertDialog.Builder(this)
                                        .setTitle(R.string.sorry)
                                        .setMessage(getString(R.string.saf_wrong_select,Constants.ROOT_DIR_NAME,path))
                                        .setPositiveButton(R.string.try_again, (dialogInterface, i) -> check())
                                        .show();
                                return;
                            }
                            check();
                        } else check();
                    }
            );
        }else {
            permissionResult = registerForActivityResult(new ActivityResultContracts.RequestPermission(), result -> check());
        }
        check();
    }

    private boolean canAccessStorage(){
        return PackageManager.PERMISSION_GRANTED == ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
    }

    private void check(){
        if (Constants.isAfterAndroid10()){
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (SAFConstants.loadSavedDirectory(this,Constants.ROOT_DIR_NAME)==null){
                    requestPermission();
                    return;
                }
            }

        }else {
            if (!canAccessStorage()){
                permissionResult.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE);
                return;
            }
        }

        goToMainActivity();
    }

    @RequiresApi(api = Build.VERSION_CODES.R)
    @SuppressLint("WrongConstant")
    private void requestPermission() {
        StorageManager storageManager = (StorageManager) getSystemService(Context.STORAGE_SERVICE);
        File dir = new File(storageManager.getPrimaryStorageVolume().getDirectory(),Constants.ROOT_DIR_NAME);
        String msg = dir.exists() ? getString(R.string.saf_allow_note,Constants.ROOT_DIR_NAME) : getString(R.string.saf_create_and_allow_note,Constants.ROOT_DIR_NAME,Constants.ROOT_DIR_NAME);

        new AlertDialog.Builder(this)
                .setTitle(R.string.important)
                .setMessage(msg)
                .setPositiveButton(R.string.get_started, (dialogInterface, i) -> {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                    intent.setFlags(195);
                    intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI, SAFConstants.createInitFolderURI(storageManager,Constants.ROOT_DIR_NAME));
                    try {
                        safResult.launch(intent);
                    }catch (Exception e){
                        Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }

    private void goToMainActivity (){
        Intent i = new Intent(this, ScreenKr.class);
        startActivity(i);
        finish();
    }
}
