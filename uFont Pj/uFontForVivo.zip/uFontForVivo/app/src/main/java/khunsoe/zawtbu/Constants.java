package khunsoe.zawtbu;

import android.os.Build;
import android.os.Environment;

import java.io.File;

public class Constants {
    public static final String ROOT_DIR_NAME = ".dwd";
    public static final String DWD_FONT_PATH = ".dwd/c/o/m/b/b/k/t/h/e/m/e/F/";
    public static final File DEFAULT_DWD_PATH = new File(Environment.getExternalStorageDirectory(),DWD_FONT_PATH);

    public static boolean isAfterAndroid10(){
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.R;
    }
}
