package khunsoe.zawtbu.Utils;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Environment;
import android.util.Base64;
import android.widget.Toast;

import com.g00fy2.versioncompare.Version;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

//Vivo Font Installer By Khun Htetz Naing

public class VivoFontInstaller {
    public static String OWN_EXTENSION = ".UFONT";
    private String itz;
    Activity activity;
    public static final String OUTPUT_DIRECTORY = Environment.getExternalStorageDirectory()+"/.dwd/c/o/m/b/b/k/t/h/e/m/e/F/",key = "67b491d3101c047dfa02761b22e1d052e1cc98db32d4090dd6147a352319cd1792da707207f0f97e5ef554825e4913ea86caf157ae10e1701db318aaf95956c5f328d0387f612a4cabc09087fe3b927abe45e7aa444827d81115924dff66bc00f9c0c1dd66af234e18b959073e495b9220b0b85e64468cf61985e22c259327248260ba4ce568828ee2fa71e842d6a783d35bbdec316c3eb3f629fe4b75a1886ec4de334dd2e7ddc1c68bf8e2f4c2df4e6f9c04f430319904729f157bb63918ccb2f4f38bc902f61b42bdfeb72a84da317f8feae005aee14638c3b5524224194e03b664cc219397c91aa203400b50a26c1d263f95c6b2feef9e579f9002cd1182";;
    public static final String TEMP_DIRECTORY = Environment.getExternalStorageDirectory() + "/VivoByuFont/";;
    OnDone onDone;
    String mainFile,watchFile = null;
    boolean after60 = false;
    public static String packageName = "com.bbk.theme";
    static SharedPreferences sharedPreferences;
    static String splitKey = "HtetzNaing";

    public static void initDB(Context context){
        sharedPreferences = context.getSharedPreferences("uFonts", Context.MODE_PRIVATE);
    }

    public VivoFontInstaller(Activity activity){
        initDB(activity);
        this.activity=activity;
        try {
            PackageInfo packageInfo = activity.getPackageManager().getPackageInfo(packageName, 0);
            String iThemeVersion = packageInfo.versionName;
            iThemeVersion = iThemeVersion.substring(0, 7);
            String need = "3.5.0.0";
            after60 = new Version(iThemeVersion).isHigherThan(need);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void install(String itz) {
        this.itz = itz;
        mainFile = OUTPUT_DIRECTORY+"Vivo_By_uFont.itz";
        install();
    }

    public void changeFont(){
        File temp = new File(mainFile);
        if(temp.exists()) {
            if (isVivo()) {
                try {
                    Intent intent = activity.getPackageManager().getLaunchIntentForPackage("com.bbk.theme");
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NO_HISTORY | Intent.FLAG_ACTIVITY_NEW_TASK);
                    activity.startActivity(intent);
                } catch (Exception e) {
                    Intent localIntent = new Intent(Intent.ACTION_MAIN);
                    localIntent.setComponent(new ComponentName("com.bbk.theme", "com.bbk.theme.Theme"));
                    localIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NO_HISTORY | Intent.FLAG_ACTIVITY_NEW_TASK);
                    activity.startActivity(localIntent);
                }
            }else {
                VivoUtils.deleteDirectory(OUTPUT_DIRECTORY);
                Toast.makeText(activity, "This is not Vivo Phone!", Toast.LENGTH_SHORT).show();
            }
        }else Toast.makeText(activity, "Please install again!", Toast.LENGTH_SHORT).show();
    }

    private boolean isVivo(){
        PackageManager pm = activity.getPackageManager();
        try {
            pm.getPackageInfo("com.bbk.theme", PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException ignored) {}
        return false;
    }

    public static void addData(String json,Context context){
        if (sharedPreferences==null)initDB(context);
        try {
            JSONArray array = new JSONArray(json);
            for (int i=0;i<array.length();i++){
                JSONObject object = array.getJSONObject(i);
                String key = object.getString("key").trim();
                String name = object.getString("name").trim();
                String des = object.getString("des").trim();
                sharedPreferences.edit().putString(name,key+splitKey+des).apply();
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void install(){
        new AsyncTask<Void,Void,String>(){
            String SUCCESS="success",ERROR="error",NO_MORE="no_more";
            private String getJSON() throws IOException {
                InputStream inputStream = activity.getAssets().open("out.json");
                BufferedReader bufferedReader= new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder result = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine())!=null){
                    result.append(line).append("\n");
                }
                return result.toString();
            }

            private String[] getVivo(String font){
                String curMD5 = MD5Utils.getMD5(new File(font));
                if (sharedPreferences.getAll().isEmpty()){
                    try {
                        addData(getJSON(),activity);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

                System.out.println("Total Key => "+sharedPreferences.getAll().size());
                for (String name:sharedPreferences.getAll().keySet()){
                    File file = new File("/data/fonts/"+name+".ttf");
                    if (!file.exists()){
                        System.out.println("Not Exist => "+name);
                        String out [] = returnDate(name);
                        if (out!=null)return out;
                    }else {
                        System.out.println("Used => "+name);
                        String existMD5 = MD5Utils.getMD5(file);
                        if (curMD5.equals(existMD5)){
                            System.out.println("getVivo => Exist");
                            String out [] = returnDate(name);
                            if (out!=null)return out;
                        }
                    }
                }
                return null;
            }


            private String[] returnDate(String name){
                String data = sharedPreferences.getString(name,null);
                if (data!=null){
                    String datas[] = data.split(splitKey);
                    String des = datas[1];
                    des = new String(Base64.decode(des,Base64.DEFAULT));
                    String key = datas[0];
                    return new String[]{name,des,key};
                }
                return null;
            }

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                VivoUtils.deleteDirectory(TEMP_DIRECTORY);
            }

            @Override
            protected String doInBackground(Void... voids) {
                if (after60){
                    String fontFolder = TEMP_DIRECTORY+"fonts/";
                    if (VivoUtils.createDirectory(OUTPUT_DIRECTORY)){
                        if (VivoUtils.unZip(itz,TEMP_DIRECTORY)) {
                            VivoUtils.deleteFile(itz);
                            String keyFile = TEMP_DIRECTORY + "key";
                            String descFile = TEMP_DIRECTORY + "description.xml";
                            File font = null;
                            File folder = new File(fontFolder);

                            if (folder.listFiles() != null) {
                                for (File f : folder.listFiles()) {
                                    if (f.isFile()) {
                                        font = f;
                                    }
                                }
                            }

                            String[] info = getVivo(font.getPath());
                            if (info != null) {
                                String name = info[0], des = info[1], key = info[2];
                                //After 6.0.0
                                //Copy font file
                                if (font != null) {
                                    File newFile = new File(fontFolder + name + OWN_EXTENSION);
                                    font.renameTo(newFile);
                                }

                                //Write Key
                                VivoUtils.deleteFile(keyFile);
                                VivoUtils.writeTextFile(keyFile, key);

                                //Write DESC
                                VivoUtils.deleteFile(descFile);
                                VivoUtils.writeTextFile(descFile, des);

                                watchFile = OUTPUT_DIRECTORY + "uFonts.itz";
                                VivoUtils.writeTextFile(watchFile, "");
                                if (VivoUtils.ZipDirectory(TEMP_DIRECTORY, mainFile)){
                                    return SUCCESS;
                                }
                            }else return NO_MORE;
                        }
                    }
                }else return SUCCESS;
                return ERROR;
            }

            @Override
            protected void onPostExecute(String aBoolean) {
                super.onPostExecute(aBoolean);
                VivoUtils.deleteDirectory(TEMP_DIRECTORY);
                if (aBoolean.equals(SUCCESS)){
                    onDone.onCompleted(mainFile,watchFile,after60);
                }else if (aBoolean.equals(NO_MORE)){
                    onDone.noMore();
                }else onDone.onError();
            }

        }.execute();
    }

    public void OnFinishedListener(OnDone onDone){
        this.onDone=onDone;
    }

    public interface OnDone{
        void onCompleted(String target, String watch, boolean after60);
        void onError();
        void noMore();
    }
}
