package khunsoe.zawtbu.Service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.app.TaskStackBuilder;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicInteger;

import khunsoe.zawtbu.MainActivity;
import khunsoe.zawtbu.R;
import khunsoe.zawtbu.Utils.VivoFontInstaller;
import khunsoe.zawtbu.Utils.VivoUtils;
import static khunsoe.zawtbu.Utils.VivoFontInstaller.OWN_EXTENSION;


//Vivo Font By Khun Htetz Naing

public class VivouFontService extends Service {
    private String channel_id = "hello_world";
    public static final String WATCHING_FILE = "watch_file",TARGET_FILE="target_file",NAME = "display_name";
    public static final String ACTION_START_FOREGROUND_SERVICE = "ACTION_START_FOREGROUND_SERVICE";
    public static final String ACTION_STOP_FOREGROUND_SERVICE = "ACTION_STOP_FOREGROUND_SERVICE",DELETED_CALLBACK="deleted_folder_zfont_tool",INPUT_FILE_MULTIPLE_PATH="input_multiple";

    private AtomicInteger c = new AtomicInteger(0);

    public VivouFontService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        final int id = getID();
        channel_id = getString(R.string.app_name).replace(" ","_")+"_vivo";
        if (intent != null) {
            String action = intent.getAction();
            if(action!=null)
                switch (action) {
                    case ACTION_START_FOREGROUND_SERVICE:
                        final String watch = intent.getStringExtra(WATCHING_FILE),name = intent.getStringExtra(NAME),target=intent.getStringExtra(TARGET_FILE);
                        if (watch!=null && name!=null && target!=null){
                            final File file = new File(watch);
                            final int delay = 500;
                            final int[] count = {1};
                            final Handler handler = new Handler();
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    count[0]++;
                                    showNoti(name,""+ count[0],id);
                                    if (file.exists()){
                                        handler.postDelayed(this, delay);
                                    }else {
                                        //Time to stop
                                        new Thread(new Runnable() {
                                            @Override
                                            public void run() {
                                                String TEMP_DIRECTORY = VivoFontInstaller.TEMP_DIRECTORY;
                                                VivoUtils.deleteDirectory(TEMP_DIRECTORY);
                                                if (VivoUtils.createDirectory(TEMP_DIRECTORY)){
                                                    if (VivoUtils.unZip(target,TEMP_DIRECTORY)){
                                                        try {
                                                            delFile(new File(target),false);
                                                        } catch (IOException e) {
                                                            e.printStackTrace();
                                                        } catch (InterruptedException e) {
                                                            e.printStackTrace();
                                                        }

                                                        //Fix Font runtime
                                                        String fontFolder = TEMP_DIRECTORY+"fonts/";
                                                        File fontFiles = new File(fontFolder);
                                                        if (fontFiles.listFiles()!=null){
                                                            for (File f:fontFiles.listFiles()){
                                                                if (f.getName().endsWith(OWN_EXTENSION)){
                                                                    File newFile = new File(f.getPath().replace(OWN_EXTENSION,".ttf"));
                                                                    System.out.println("Fixed => "+f.renameTo(newFile));
                                                                }
                                                            }
                                                        }

                                                        //Compress
                                                        if (VivoUtils.ZipDirectory(TEMP_DIRECTORY,target)){
                                                            try {
                                                                delFile(new File(TEMP_DIRECTORY),true);
                                                            } catch (IOException e) {
                                                                e.printStackTrace();
                                                            } catch (InterruptedException e) {
                                                                e.printStackTrace();
                                                            }
                                                        }
                                                    }
                                                }
                                                stopForegroundService();
                                            }
                                        }).start();
                                    }
                                }
                            },delay);
                            showNoti(name,""+ count[0],id);
                        }
                        break;
                    case ACTION_STOP_FOREGROUND_SERVICE:
                        stopForegroundService();
                        Toast.makeText(getApplicationContext(), "Foreground service is stopped.", Toast.LENGTH_LONG).show();
                        break;
                }
        }
        return START_STICKY;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void createNotificationChannel(){
        NotificationChannel chan = new NotificationChannel(channel_id, getString(R.string.app_name), NotificationManager.IMPORTANCE_DEFAULT);
        chan.setLightColor(Color.BLUE);
        chan.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        assert manager != null;
        manager.createNotificationChannel(chan);
    }

    private void showNoti(String title,String count,int id) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            createNotificationChannel();
        }
        Intent resultIntent = new Intent(this, MainActivity.class);
        TaskStackBuilder stackBuilder = TaskStackBuilder.create(this);
        stackBuilder.addNextIntentWithParentStack(resultIntent);
        PendingIntent resultPendingIntent = stackBuilder.getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT);
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this, channel_id);
        notificationBuilder = notificationBuilder
                .setOngoing(false)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentText(title)
                .setContentTitle(String.format("Checking %s",count))
                .setContentIntent(resultPendingIntent);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            notificationBuilder
                    .setPriority(NotificationManager.IMPORTANCE_MIN)
                    .setCategory(Notification.CATEGORY_SERVICE);
        }

        Notification notification = notificationBuilder.build();
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        notificationManager.notify(id, notificationBuilder.build());
        startForeground(id, notification);
    }


    private int getID() {
        return c.incrementAndGet();
    }

    private void stopForegroundService() {
        System.out.println("Fixed LOL :3");
        // Stop foreground service and remove the notification.
        stopForeground(true);
        // Stop the foreground service.
        stopSelf();
    }

    private static void delFile(File file, boolean isDir ) throws IOException, InterruptedException {
        if ( file.exists() ) {
            String rm = "rm -f";
            if (isDir)rm = "rm -rf";
            // Secure and correct
            String target = file.getName();
            Runtime runtime = Runtime.getRuntime();
            Process process = runtime.exec( new String[] {
                    "sh", "-c", "cd "+file.getParentFile().getPath()+" && "+rm+" \"$1\"", "--", target
            } );
            process.waitFor();
        }

    }
}
