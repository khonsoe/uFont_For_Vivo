package khunsoe.zawtbu;

public class Ads
{
    public static final String adid="ca-app-pub-2550685256430558~5676643251";
    public static final String ad="ca-app-pub-2550685256430558/5374240980";
    public static final String ba="ca-app-pub-2550685256430558/6417172995";
}