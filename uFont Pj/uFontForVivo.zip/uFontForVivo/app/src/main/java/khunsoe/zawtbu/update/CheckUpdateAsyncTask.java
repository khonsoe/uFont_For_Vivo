package khunsoe.zawtbu.update;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.provider.MediaStore;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class CheckUpdateAsyncTask {
    private Activity activity;
    private String downloadPath;
    private DownloadManager mDownloadManager;
    private long downloadedFileID;
    private DownloadManager.Request mRequest;
    private int versionCode=0;
    private String json_url;

    ProgressDialog alert2;

    public CheckUpdateAsyncTask(Activity activity, String json_url) {
        this.json_url = json_url;
        this.activity = activity;

        mDownloadManager = (DownloadManager) activity.getSystemService(Context.DOWNLOAD_SERVICE);
        downloadPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getPath()+"/";
        File n = new File(downloadPath);
        if (!n.exists()){
            n.mkdirs();
        }

        checkUpdate();
    }

    private void checkUpdate() {
        new AsyncTask<Void,Void,String>(){
            @Override
            protected String doInBackground(Void... voids) {

                try {
                    return fetch(json_url);
                } catch (Exception e) {
                    return e.getMessage();
                }
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                if (s!=null){
                    letCheck(s);
                }
            }
        }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
    }

    private void letCheck(String response){

        if (response!=null) {
            try {
                JSONObject obj = new JSONObject(response);
                String title = obj.getString("title");
                String msg = obj.getString("message");
                boolean force = obj.getBoolean("force");
                versionCode = obj.getInt("versionCode");

                PackageManager manager = activity.getPackageManager();
                PackageInfo info;
                int currentVersion = 0;
                try {
                    info = manager.getPackageInfo(activity.getPackageName(), 0);
                    currentVersion = info.versionCode;
                } catch (PackageManager.NameNotFoundException e) {
                    e.printStackTrace();
                }

                if (versionCode > currentVersion){
                    letUpdate(title,msg, force);
                }

            } catch (JSONException e) {
            }
        }}

    private void letUpdate(final String title, final String message, final boolean force){

        final AlertDialog ad = new AlertDialog.Builder(activity).create();
        ad.setTitle(title);
        ad.setMessage(message);
        ad.setCancelable(!force);
        ad.setCancelable(false);
        if (!force){
            ad.setButton(AlertDialog.BUTTON_NEGATIVE, "Cancel", new DialogInterface.OnClickListener(){
                @Override
                public void onClick(DialogInterface p1, int p2)
                {
                    //ad.dismiss();
                    activity.finish();
                }}); }
        ad.setButton(AlertDialog.BUTTON_NEUTRAL, "Update", new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface p1, int p2)
            {
                openInPlayStore();
                activity.finish();
            }});

        ad.show();
    }

    private void openInPlayStore(){
        activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + activity.getPackageName())));
    }


    private BroadcastReceiver downloadReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            final Uri uri = mDownloadManager.getUriForDownloadedFile(downloadedFileID);
            final String apk = getRealPathFromURI(uri);
        }
    };


    private String getRealPathFromURI (Uri contentUri) {
        String path = null;
        String[] proj = { MediaStore.MediaColumns.DATA };
        Cursor cursor = activity.getContentResolver().query(contentUri, proj, null, null, null);
        if (cursor.moveToFirst()) {
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);
            path = cursor.getString(column_index);
        }
        cursor.close();
        return path;
    }

    private String fetch(String link)
    {
        String result = "";
        try {
            URL url = new URL(link);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK){
                InputStream inputStream = connection.getInputStream();
                ByteArrayOutputStream ba = new ByteArrayOutputStream();
                byte[] buffer = new byte[1024];
                int length;

                while ((length = inputStream.read(buffer)) != -1){
                    ba.write(buffer, 0, length);
                }
                ba.close();
                result = ba.toString("UTF-8");
            }}
        catch (Exception e)
        {
            result = e.getMessage();
        }
        return result;
    }
}