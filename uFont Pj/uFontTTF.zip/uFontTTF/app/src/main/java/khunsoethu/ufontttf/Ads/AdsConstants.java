package khunsoethu.ufontttf.Ads;

public class AdsConstants {
    public static final String APP_ID="ca-app-pub-2550685256430558~4687079965";
    public static final String APP_OPEN ="No";
    public static final String INTERSTITIAL ="ca-app-pub-2550685256430558/3182426600";
    public static final String REWARDED ="No";
}
