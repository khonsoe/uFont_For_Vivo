package khunsoethu.ufontttf;
import android.annotation.SuppressLint;
import android.app.*;
import android.content.*;
import android.database.*;
import android.net.*;
import android.os.*;
import android.util.*;

import java.lang.reflect.*;

public class DownloadReceiver extends BroadcastReceiver
{
	@Override
	public void onReceive(Context context, Intent intent)
	{
		long id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
		String lastData=getFromPrefs(context,"ids");
		if (lastData.contains(id+"")) {
			DownloadManager dm=(DownloadManager)context.getSystemService(context.DOWNLOAD_SERVICE);
			DownloadManager.Query query = new DownloadManager.Query();
			query.setFilterById(id);

			Cursor downloadResult = dm.query(query);

			if (downloadResult.moveToFirst()) {
				int statusColumnIndex = downloadResult.getColumnIndex(DownloadManager.COLUMN_STATUS);
				int status = downloadResult.getInt(statusColumnIndex);

				if (status == DownloadManager.STATUS_SUCCESSFUL) {
					//download completed successfully
					//int localFileNameId = downloadResult.getColumnIndex(DownloadManager.COLUMN_LOCAL_FILENAME);
					@SuppressLint("Range") String downloadPathFile = (downloadResult.getString(downloadResult.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI))).replace("file://","");
					//String downloadPathFile = downloadResult.getString(localFileNameId);
					//String downloadPathDir = downloadPathFile.substring(0, downloadPathFile.lastIndexOf("/") + 1);
					String downloadName = downloadPathFile.substring(downloadPathFile.lastIndexOf("/") + 1);
					Log.i("name =", downloadName);

					//File file = new File(downloadPathDir);
					//File[] files = file.listFiles();
					//for (File f : files) {
						//if (f.isFile() && f.exists() && !f.getName().equals(downloadName)) {
							//f.delete();
						//}
					//}
					if(Build.VERSION.SDK_INT>=24) {
						try {
							Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
							m.invoke(null);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
					Intent intent2 = new Intent(Intent.ACTION_VIEW);
					intent2.setDataAndType(Uri.parse("file://"+downloadPathFile), "application/vnd.android.package-archive");
					intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					context.startActivity(intent2);

				}
			}
		}
	}

	public String getFromPrefs(Context context,String key){
		SharedPreferences sharedPreferences = context.getSharedPreferences("MyData", Context.MODE_PRIVATE);
		String lastData= sharedPreferences.getString("ids","");
		return lastData;
	}
}
