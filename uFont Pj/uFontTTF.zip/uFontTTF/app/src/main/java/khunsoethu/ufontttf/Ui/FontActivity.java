package khunsoethu.ufontttf.Ui;


import android.annotation.SuppressLint;
import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.util.Log;
import android.view.*;
import android.widget.*;

import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.squareup.picasso.*;
import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Locale;
import java.util.Objects;

import android.content.Intent;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.documentfile.provider.DocumentFile;

import android.os.Bundle;
import android.view.View;

import org.jetbrains.annotations.NotNull;

import khunsoethu.ufontttf.Ads.AdsConstants;
import khunsoethu.ufontttf.Constants;
import khunsoethu.ufontttf.R;
import khunsoethu.ufontttf.SAFConstants;

import static android.view.View.*;


public class FontActivity extends AppCompatActivity {
    TextView txtv;
    ImageView imv;
    String title, link, image, desc;
    androidx.appcompat.widget.Toolbar tb;

    private InterstitialAd mInterstitialAd; //mInterstitialAd

    private final boolean euConsent= true;
    private String TAG;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_font);

        tb = findViewById(R.id.kr_toolbar2);
        setSupportActionBar(tb);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(@NotNull InitializationStatus initializationStatus) {
                if (euConsent){
                    AdpShow();
                }else {
                    AdpShowError();
                }
            }
        });
        AdView mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
    }

    private void AdpShow() {
        AdRequest adRequest = new AdRequest.Builder().build();
        AdInterstitialAd(adRequest);
    }
    private void AdpShowError() {
        Bundle networkExtrasBundle = new Bundle();
        networkExtrasBundle.putInt("rdp", 1);
        AdRequest adRequest = new AdRequest.Builder()
                .addNetworkExtrasBundle(AdMobAdapter.class, networkExtrasBundle)
                .build();
        AdInterstitialAd(adRequest);
    }

    private void AdInterstitialAd(AdRequest adRequest) {
        com.google.android.gms.ads.interstitial.InterstitialAd.load(this, AdsConstants.INTERSTITIAL, adRequest, new InterstitialAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull com.google.android.gms.ads.interstitial.InterstitialAd interstitialAd) {
                // The mInterstitialAd reference will be null until
                // an ad is loaded.
                mInterstitialAd = interstitialAd;
                Log.i(TAG, "onAdLoaded");
                mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override
                    public void onAdDismissedFullScreenContent() {
                        // Called when fullscreen content is dismissed.
                        Log.d("TAG", "The ad was dismissed.");
                        if (euConsent) {
                            AdpShow();
                        } else {
                            AdpShowError();
                        }
                    }
                    @Override
                    public void onAdFailedToShowFullScreenContent(@NotNull AdError adError) {
                        // Called when fullscreen content failed to show.
                        Log.d("TAG", "The ad failed to show.");
                    }
                    @Override
                    public void onAdShowedFullScreenContent() {
                        mInterstitialAd = null;
                        Log.d("TAG", "The ad was shown.");
                    }
                });
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                // Handle the error
                Log.i(TAG, loadAdError.getMessage());
                mInterstitialAd = null;
            }
        });

        txtv = findViewById(R.id.textvvi);
        imv = findViewById(R.id.imvvi);
        Intent intent = getIntent();
        title = intent.getStringExtra("title");
        link = intent.getStringExtra("link");
        image = intent.getStringExtra("image");
        desc = intent.getStringExtra("desc");
        Log.e("LINK: ", link);
        setTitle(title);
        Picasso.with(this)
                .load(image)
                .into(imv);
        txtv.setText(String.format("%s\n\n%s", title,desc));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }


    public void downloadClick(View v) {
        //downloadFromUrl();
        //download(link);
       new DownloadFileAsync(FontActivity.this).execute(link);
        //showAD();
    }

    private DocumentFile getDocumentFile(){
        DocumentFile documentFile = null;
        if (Constants.isAfterAndroid10()){
            Uri uri = SAFConstants.loadSavedDirectory(this,Constants.ROOT_DIR_NAME);
            if (uri != null){
                documentFile = DocumentFile.fromTreeUri(this,uri);
                for (String k:Constants.DWD_FONT_PATH.split("/")) {
                    if (!k.equalsIgnoreCase(Constants.ROOT_DIR_NAME))
                        documentFile = SAFConstants.findFolder(documentFile, k);
                }
            }
        }
        return documentFile;
    }

    public void showAD(){
        if (mInterstitialAd != null) {
            mInterstitialAd.show(FontActivity.this);
        } else {
            Log.d("TAG", "The interstitial ad wasn't ready yet.");
        }
    }

    @SuppressLint("StaticFieldLeak")
    class DownloadFileAsync extends AsyncTask<String, String, String> {


        private final Context context;
        private Dialog mDialog;
        private TextView text, pp;
        private ProgressBar progressBar;
        MaterialButton cancel;

        public DownloadFileAsync(Context context) {
            this.context = context;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            mDialog = new Dialog(context, R.style.Theme_AppCompat_Translucent);
            mDialog.setContentView(R.layout.custom_dialog);
            text = mDialog.findViewById(R.id.ttt);
            progressBar = mDialog.findViewById(R.id.progressBar3);
            pp = mDialog.findViewById(R.id.pp);
            pp.setText("0%");
            progressBar.setMax(100);
            TextView text2 = mDialog.findViewById(R.id.title);
            text2.setText("Download Data...");
            mDialog.setCancelable(false);
            mDialog.show();
            cancel = mDialog.findViewById(R.id.cl);
            cancel.setOnClickListener(new OnClickListener() {
                public void onClick(View v) {
                    mDialog.dismiss();
                    mDialog.cancel();
                    Toast.makeText(context, "Cancel", Toast.LENGTH_SHORT).show();
                }
            });
            //  if (!mDialog.isShowing()) {
            ////////
        }

        @Override
        protected String doInBackground(String... aurl) {
            int count;
            try {
                URL url = new URL(aurl[0]);
                URLConnection conexion = url.openConnection();
                conexion.connect();
                int lenghtOfFile = conexion.getContentLength();

                InputStream input = new BufferedInputStream(url.openStream());
                OutputStream output = null;
                if (Constants.isAfterAndroid10()){
                    DocumentFile documentFile = getDocumentFile();
                    if (documentFile!=null) {
                        documentFile = documentFile.createFile("*/*", title + ".ttf");
                        output = getContentResolver().openOutputStream(Objects.requireNonNull(documentFile).getUri());
                    }
                }else {
                    File pngDir = Constants.DEFAULT_DWD_PATH;
                    if (pngDir.mkdirs()) ;
                    File file = new File(pngDir, title + ".ttf");
                    //File file = new File(pngDir, "uFont.itz");
                    output = new FileOutputStream(file);
                }
                byte data[] = new byte[1024];
                long total = 0;
                while ((count = input.read(data)) != -1) {
                    total += count;
                    String prog = ("" + (int) ((total * 100) / lenghtOfFile));
                    doProgress(formatBytes(total) + "/" + formatBytes(lenghtOfFile), prog);
                    output.write(data, 0, count);
                }
                output.flush();
                output.close();
                input.close();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
                return "e";
            }
            return "ok";
        }

        public void doProgress(String s, String p) {
            publishProgress(s, p);
        }

        protected void onProgressUpdate(String... progress) {
            Log.e("ANDRO_ASYNC", progress[0]);
            progressBar.setProgress(Integer.parseInt(progress[1]));
            pp.setText(progress[1] + "%");
            text.setText(progress[0]);
        }

        @Override
        protected void onPostExecute(String unused) {
            if (unused.equals("ok")) {
                //final String pngDir = Environment.getExternalStorageDirectory() +"/.dwd/c/o/m/b/b/k/t/h/e/m/e/F/";
                //File pngDir = new File(context.getExternalFilesDir(null), "app");
                File pngDir = Constants.DEFAULT_DWD_PATH;
                if (pngDir.mkdirs()) ;
                //File file = new File(pngDir, "uFont.itz");
                //File to = new File(pngDir, "uFont.itz");
                File file = new File(pngDir, title + ".ttf");
                File to = new File(pngDir, title + ".ttf");
                //file.renameTo(to);
                mDialog.dismiss();
                //showAD();
                DownDone();
                Log.e("onPostExecute: ", "ok");
            } else {
                Log.e("onPostExecute: ", "error");
                mDialog.dismiss();
            }
        }

    }

    private void DownDone() {
        new MaterialAlertDialogBuilder(FontActivity.this, R.style.MaterialAlertDialog)
        .setTitle("Done")
        .setMessage("Download Font Successfully!😎 Font file Save to File Manager/Device storage/Fonts/")
        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                showAD();
            }
        })
       .setNegativeButton("View Path", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //showAD();
                vpt();
            }
        })

        .show();
    }

    public static String formatBytes(long bytes) {
        Locale locale = Locale.getDefault();
        if (bytes < 1024) {
            return String.format(locale, "%d B", bytes);
        } else if (bytes < 1024 * 1024) {
            return String.format(locale, "%.2f KB", bytes / 1024d);
        } else {
            return String.format(locale, "%.2f MB", bytes / 1024d / 1024d);

        }

    }
    public void vpth(View v) {
        vpt();
    }

    public void vpt() {
        new MaterialAlertDialogBuilder(FontActivity.this, R.style.MaterialAlertDialog)
        .setTitle("Path")
        .setMessage("Font file Save to File Manager/Device storage/Fonts/")
        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                //showAD();
            }
        })

        .show();
    }

}