package khunsoethu.ufontttf.Ui;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import java.util.Timer;
import java.util.TimerTask;

import khunsoethu.ufontttf.R;

public class StartActivity extends Activity {

    private static final int WAIT_TIME = 2500;
    private Timer wt;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        wt = new Timer();
        wt.schedule(new TimerTask() {
            @Override
            public void run() {
                StartActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        startMainActivity();
                    }
                });
            }
        }, WAIT_TIME);
    }

    private void startMainActivity() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
