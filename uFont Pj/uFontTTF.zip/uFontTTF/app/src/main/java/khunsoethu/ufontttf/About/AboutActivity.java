package khunsoethu.ufontttf.About;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.LinearLayout;


import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import khunsoethu.ufontttf.R;

public class AboutActivity extends AppCompatActivity {

    public Toolbar tb;
    LinearLayout dev;
    WebView webView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
        tb = findViewById(R.id.about_tb);
        tb.setTitle("About App");
        setSupportActionBar(tb);
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        tb.setNavigationOnClickListener(v -> finish());

        webView = findViewById(R.id.up_t);
        webView.loadUrl("file:///android_res/raw/changelogs");
        webView.setBackgroundColor(Color.TRANSPARENT);
        dev = findViewById(R.id.dev);
        dev.setOnClickListener(v -> {
            startActivity(new Intent(getApplicationContext(), Dev.class));
            //Toast.makeText(context, R.string.cancel, Toast.LENGTH_SHORT).show();
        });
    }
    public void share(View v){
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("text/plain");
        intent.putExtra("android.intent.extra.TEXT","uFont TTF Download Free App\n"+"http://play.google.com/store/apps/details?id=" + getPackageName() +"\nThanks for your encouragement");
        startActivity(new Intent(Intent.createChooser(intent, "uFont TTF")));

        }

        public void gmail(View v) {
            Intent intent = new Intent("android.intent.action.SEND");
            intent.setType("message/rfc822");
            intent.putExtra("android.intent.extra.EMAIL", new String[]{"khonsoezawthu@gmail.com"});
            intent.putExtra("android.intent.extra.SUBJECT", "Hi");
            intent.putExtra("android.intent.extra.TEXT", "your mess");
            intent.setPackage("com.google.android.gm");
            try {
                startActivity(Intent.createChooser(intent, "Send Mail..."));
            } catch (Exception ignored) {
            }
        }
    }