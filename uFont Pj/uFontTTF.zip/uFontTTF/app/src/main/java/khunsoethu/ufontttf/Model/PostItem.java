package khunsoethu.ufontttf.Model;

public class PostItem
{
	//public String updated="";
	public String title="";
	public String link="";
	public String thumbnailUrl="";
	public String desc="";
}
