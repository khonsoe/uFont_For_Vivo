package khunsoethu.ufontttf.Ui;

import android.app.*;
import android.content.*;
import android.content.res.*;
import android.net.*;
import android.os.*;

import androidx.annotation.NonNull;
import androidx.core.view.*;
import androidx.appcompat.app.*;
import android.text.*;
import android.util.Log;
import android.view.*;
import android.widget.*;

import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;

import khunsoethu.ufontttf.Ads.AdsConstants;
import khunsoethu.ufontttf.Utils.Down;
import khunsoethu.ufontttf.Model.PostItem;
import khunsoethu.ufontttf.R;
import khunsoethu.ufontttf.Update.CheckUpdateAsyncTask;
import com.squareup.picasso.*;
import java.util.*;

import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import org.jetbrains.annotations.NotNull;

public abstract class ListActivity extends AppCompatActivity {
	public abstract void processJson(String jsonString);

	public abstract boolean useGridLayout();

	public abstract String getFeedAddress();

	public abstract void _Options_Menu_Click(MenuItem item);

	private SwipeRefreshLayout mSwipeLayout;
	RecyclerView rv;
	FeedAdapter adapter;
	List<PostItem> posts, filteredposts;
	boolean online = true;
	Toolbar tb;
	String currentLink = "";
	final int FONT_NONE = 0;
	int currentFont = FONT_NONE;

	DrawerLayout mDrawerLayout;
	private ActionBarDrawerToggle mDrawerToggle;
	private NavigationView navigationView;

	private AdView mAdView;
	private InterstitialAd mInterstitialAd; //mInterstitialAd

	private final boolean euConsent= true;
	private String TAG;
	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		tb = findViewById(R.id.kr_toolbar);
		setSupportActionBar(tb);

		new CheckUpdateAsyncTask(this, "https://raw.githubusercontent.com/khonsoe/updatevivo/master/uFontttf.json");


		navigationView = (NavigationView) findViewById(R.id.ngv);
		mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
		mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, 0, 0);
		//mDrawerLayout.setDrawerListener(mDrawerToggle);
		mDrawerLayout.addDrawerListener(mDrawerToggle);
		Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
		setupNV();

		assert navigationView != null;
		navigationView.setItemIconTintList(null);

		navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
			@Override
			public boolean onNavigationItemSelected(@NotNull MenuItem menuItem) {
				menuItem.setChecked(true);
				mDrawerLayout.closeDrawers();
				//_MenuItem_Click(menuItem.getItemId());
				_Options_Menu_Click(menuItem);
				return true;
			}
		});
		FloatingActionButton fab = findViewById(R.id.fab);
		fab.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				Intent intent =new Intent("android.intent.action.SEND");
				intent.setType("text/plain");
				intent.putExtra("android.intent.extra.TEXT","Download to Play Store\n\nhttps://play.google.com/store/apps/details?id=khunsoethu.ufontttf\n\nThanks for your encouragement😍");
				startActivity(new Intent(Intent.createChooser(intent, "uFont TTF")));
			}
		});


		MobileAds.initialize(this, new OnInitializationCompleteListener() {
			@Override
			public void onInitializationComplete(@NotNull InitializationStatus initializationStatus) {
				if (euConsent){
					AdpShow();
				}else {
					AdpShowError();
				}
			}
		});
	}
	private void AdpShow() {
		AdRequest adRequest = new AdRequest.Builder().build();
		AdInterstitialAd(adRequest);
	}
	private void AdpShowError() {
		Bundle networkExtrasBundle = new Bundle();
		networkExtrasBundle.putInt("rdp", 1);
		AdRequest adRequest = new AdRequest.Builder()
				.addNetworkExtrasBundle(AdMobAdapter.class, networkExtrasBundle)
				.build();
		AdInterstitialAd(adRequest);
	}
	private void AdInterstitialAd(AdRequest adRequest) {
		InterstitialAd.load(this, AdsConstants.INTERSTITIAL, adRequest, new InterstitialAdLoadCallback() {
			@Override
			public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
				// The mInterstitialAd reference will be null until
				// an ad is loaded.
				mInterstitialAd = interstitialAd;
				Log.i(TAG, "onAdLoaded");
				mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
					@Override
					public void onAdDismissedFullScreenContent() {
						// Called when fullscreen content is dismissed.
						Log.d("TAG", "The ad was dismissed.");
						if (euConsent) {
							AdpShow();
						} else {
							AdpShowError();
						}
					}

					@Override
					public void onAdFailedToShowFullScreenContent(AdError adError) {
						// Called when fullscreen content failed to show.
						Log.d("TAG", "The ad failed to show.");
					}

					@Override
					public void onAdShowedFullScreenContent() {
						// Called when fullscreen content is shown.
						// Make sure to set your reference to null so you don't
						// show it a second time.
						mInterstitialAd = null;
						Log.d("TAG", "The ad was shown.");
					}
				});
			}

			@Override
			public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
				// Handle the error
				Log.i(TAG, loadAdError.getMessage());
				mInterstitialAd = null;
			}
		});

		mSwipeLayout = (SwipeRefreshLayout) findViewById(R.id.swipeRefreshLayout);
		mSwipeLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
			@Override
			public void onRefresh() {
				if (isOnline())
					refresh();
				else {
					mSwipeLayout.setRefreshing(false);
					//net error
					netError();
				}
			}
		});
		mSwipeLayout.setColorSchemeResources(
				R.color.refresh_progress_1,
				R.color.refresh_progress_2,
				R.color.refresh_progress_3);

		posts = new ArrayList<PostItem>();
		filteredposts = new ArrayList<PostItem>();
		rv = (RecyclerView) findViewById(R.id.revlist);
		if (useGridLayout()) {
			rv.setLayoutManager(new GridLayoutManager(this, 1));
		} else {
			rv.setLayoutManager(new LinearLayoutManager(this));
		}
		SharedPreferences sharedPreferences = getSharedPreferences("MyData", Context.MODE_PRIVATE);
		currentFont = sharedPreferences.getInt("font_main", 0);
		refresh();
	}

	private void setupNV() {
		navigationView.getMenu().clear();
		navigationView.inflateMenu(R.menu.navigation_menu);
	}

	protected void onPostCreate(Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		mDrawerToggle.syncState();
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		mDrawerToggle.onConfigurationChanged(newConfig);
	}

	public void netError() {
		//Toast.makeText(getApplicationContext(),"No internet connection",Toast.LENGTH_SHORT).show();
		//ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		//NetworkInfo ni = cm.getActiveNetworkInfo();
		//if (ni == null) {
		new MaterialAlertDialogBuilder(ListActivity.this, R.style.MaterialAlertDialog)
		.setIcon(R.drawable.net_error)
		.setTitle("Internet Error")
		.setMessage("No Internet connection")
		.setCancelable(false)
		.setPositiveButton("Try Again", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				refresh();
			}
		})
		//No.Button
		.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		})
		.show();
	}

	public void refresh() {
		//adapter.reset();
		currentLink = getFeedAddress();
		tb.collapseActionView();
		if (isOnline()) {
			online = true;
			new DownloadTask().execute(currentLink);
		} else {
			online = false;
			//netError
			netError();
			//Toast.makeText(getApplicationContext(),"No internet connection",Toast.LENGTH_SHORT).show();

			try {
				processJson(getFromPrefs(currentLink));
				adapter = new FeedAdapter();
				rv.setAdapter(adapter);
			} catch (Exception e) {
				Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();
			}
		}
	}

	public void saveToPrefs(String result) {
		SharedPreferences sharedPreferences = getSharedPreferences("MyData", Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = sharedPreferences.edit();
		editor.putString(currentLink, result);
		editor.commit();
	}

	public String getFromPrefs(String key) {

		SharedPreferences sharedPreferences = getSharedPreferences("MyData", Context.MODE_PRIVATE);
		String lastData = sharedPreferences.getString(currentLink, "");
		return lastData;
	}

	private class DownloadTask extends AsyncTask<String, Void, String> {
		@Override
		protected void onPreExecute() {
			mSwipeLayout.setRefreshing(true);
		}

		@Override
		protected String doInBackground(String... p1) {
			String result = Down.download(p1[0]);
			return result;
		}

		@Override
		public void onPostExecute(String result) {
			processJson(result);
			saveToPrefs(result);
			mSwipeLayout.setRefreshing(false);
			adapter = new FeedAdapter();
			rv.setAdapter(adapter);
		}
	}

	protected boolean isOnline() {
		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo netInfo = cm.getActiveNetworkInfo();
		if (netInfo != null && netInfo.isConnectedOrConnecting()) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main_menu, menu);
		MenuItem myActionMenuItem = menu.findItem(R.id.menu_search);
		SearchView sv = (SearchView) myActionMenuItem.getActionView();
		sv.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
			@Override
			public boolean onQueryTextSubmit(String p1) {
				return false;
			}

			@Override
			public boolean onQueryTextChange(String p1) {
				adapter.filter(p1.toString());
				return false;
			}
		});
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int id = item.getItemId();
		if (id == android.R.id.home) {
			mDrawerLayout.openDrawer(GravityCompat.START);
			return true;
		} else {
			_Options_Menu_Click(item);
		}
		return super.onOptionsItemSelected(item);
	}

	public void addItem(PostItem item) {
		posts.add(item);
	}

	public class FeedAdapter extends RecyclerView.Adapter<FeedAdapter.ViewHolder> {
		@Override
		public FeedAdapter.ViewHolder onCreateViewHolder(ViewGroup p1, int p2) {
			View v = getLayoutInflater().inflate(R.layout.list_adapter, p1, false);
			return new ViewHolder(v);
		}

		public void filter(String charText) {
			charText = charText.toLowerCase();
			filteredposts.clear();
			if (charText.length() == 0) {
				filteredposts.addAll(posts);
			} else {
				for (PostItem pi : posts) {
					if (pi.title.toLowerCase().contains(charText)) {
						filteredposts.add(pi);
					}
				}
			}
			notifyDataSetChanged();
		}

		@Override
		public int getItemCount() {
			return filteredposts.size();
		}

		@Override
		public void onBindViewHolder(FeedAdapter.ViewHolder p1, int p2) {
			if ((filteredposts.get(p2).thumbnailUrl.length() > 0) && (online)) {
				Picasso
						.with(getApplicationContext())
						.load(Html.fromHtml(filteredposts.get(p2).thumbnailUrl).toString())
						.into(p1.imv);
			} else {
				p1.imv.setImageResource(R.drawable.ic_refresh);
			}
			p1.txtv.setText(filteredposts.get(p2).title);
		}

		public PostItem getItem(int pos) {
			return filteredposts.get(pos);
		}

		public void reset() {
			posts.clear();
			filteredposts.clear();
			notifyDataSetChanged();
		}

		public FeedAdapter() {
			super();
			filteredposts = new ArrayList<PostItem>();
			filteredposts.addAll(posts);
		}


		public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
			ImageView imv;
			TextView txtv;


			@Override
			public void onClick(View view) {
				Intent i = new Intent(ListActivity.this, FontActivity.class);
				PostItem pi = filteredposts.get(getAdapterPosition());
				i.putExtra("title", pi.title);
				i.putExtra("link", pi.link);
				i.putExtra("desc", pi.desc);
				i.putExtra("image", pi.thumbnailUrl);
				startActivity(i);
				//showAD();
			}

			public ViewHolder(View view) {
				super(view);
				imv = view.findViewById(R.id.item_image);
				txtv = view.findViewById(R.id.tvItemText);
				view.setOnClickListener(this);
			}
		}
	}

	public void showAD(){
		if (mInterstitialAd != null) {
			mInterstitialAd.show(ListActivity.this);
		} else {
			Log.d("TAG", "The interstitial ad wasn't ready yet.");
		}
	}
	public void MsgBox(String title, String msg) {
		new MaterialAlertDialogBuilder(ListActivity.this, R.style.MaterialAlertDialog)
		.setTitle(title)
		.setMessage(msg)
		.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		})
		.show();
	}

	@Override
	public void onBackPressed() {
		new MaterialAlertDialogBuilder(ListActivity.this, R.style.MaterialAlertDialog)
			.setIcon(R.mipmap.ic_launcher)
			.setTitle("Aer you enjoying my app?")
			.setMessage("Please give a review.")
			//alert.setView(getLayoutInflater().inflate(R.layout.img,null));
			//Yes Button
			.setPositiveButton("SURE",new DialogInterface.OnClickListener(){
				@Override
				public void onClick(DialogInterface dialog,int which)
				{
					rate();
				}})
			//No.Button
			.setNegativeButton("No,Thanks",new DialogInterface.OnClickListener(){
				@Override
				public void onClick(DialogInterface dialog,int which){
					dialog. dismiss();
					finish();
					
				}

			})
			.show();
		}
	public void rate(){
		try {
			startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getPackageName())));
		} catch (android.content.ActivityNotFoundException anfe) {
			startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName())));
		}
	}
}