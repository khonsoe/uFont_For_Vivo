package khunsoethu.ufontttf.About;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;



import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.button.MaterialButton;

import khunsoethu.ufontttf.R;

public class Dev extends AppCompatActivity {

    public Toolbar tb;
    MaterialButton dev;
    final String mapp="KHUN SOE ZAW THU";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dev);
        tb = (Toolbar) findViewById(R.id.about_tb);
        tb.setTitle("App Developer");
        setSupportActionBar(tb);
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        tb.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
        public void kzt_utb(View v){
        startActivity(new Intent("android.intent.action.VIEW").setData(Uri.parse("http://youtube.com")));
    }
    public void pl_st(View v){
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=pub:"+ mapp)));
        } catch (android.content.ActivityNotFoundException anfe) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/search?q=pub:"+ mapp)));
        }
    }




}
