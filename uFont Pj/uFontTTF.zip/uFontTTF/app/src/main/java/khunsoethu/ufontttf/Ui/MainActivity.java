package khunsoethu.ufontttf.Ui;
import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.text.*;
import android.view.*;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.util.*;
import org.json.*;

import khunsoethu.ufontttf.About.AboutActivity;
import khunsoethu.ufontttf.Model.PostItem;
import khunsoethu.ufontttf.R;

public class MainActivity extends ListActivity
{

	String[] links={
			"https://raw.githubusercontent.com/khonsoe/uFont_Fonts/main/Html/English.html",
			"https://raw.githubusercontent.com/khonsoe/uFont_Fonts/main/Html/Chinese.html",
			"https://raw.githubusercontent.com/khonsoe/uFont_Fonts/main/Html/Khmer.html",
			"https://raw.githubusercontent.com/khonsoe/uFont_Fonts/main/Html/Korean.html",
			"https://raw.githubusercontent.com/khonsoe/uFont_Fonts/main/Html/Lao.html",
			"https://raw.githubusercontent.com/khonsoe/uFont_Fonts/main/Html/Myanmar.html",
			"https://raw.githubusercontent.com/khonsoe/uFont_Fonts/main/Html/Shan.html",
			"https://raw.githubusercontent.com/khonsoe/uFont_Fonts/main/Html/TaiTham.html",
			"https://raw.githubusercontent.com/khonsoe/uFont_Fonts/main/Html/Thai.html",
			"https://raw.githubusercontent.com/khonsoe/uFont_Fonts/main/Html/TitleFonts.html",
	};

	String[] titles={
			"English Fonts",
			"Chinese Fonts",
			"Khmer Fonts",
			"Korean Fonts",
			"Lao Fonts",
			"Myanmar Fonts",
			"Shan Fonts",
			"Tai Tham Fonts",
			"Thai Fonts",
			"Title Fonts",
	};
	
	int current=0;

	@Override
	public void _Options_Menu_Click(MenuItem item)
	{
		int id=item.getItemId();
		if (id == R.id.about)
		{
			startActivity(new Intent(getApplicationContext(), AboutActivity.class));
			/*View view = getLayoutInflater().inflate(R.layout.about,null);
			new MaterialAlertDialogBuilder(MainActivity.this, R.style.MaterialAlertDialog)
					.setView(view)
					.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which){
							dialog. dismiss();}
					})
					.show();
			showAD();

			 */

		}else if(id==R.id.more_app){
			MoreApp("KHUN SOE ZAW THU");
			//showAD();
		}else if(id==R.id.rate_app) {
			rate();
			//showAD();
	    }else if(id==R.id.path) {
			MsgBox("Path","Download Font Successfully!😎 Font file Save to File Manager/Device storage/Fonts/");
		//showAD();
		}
		else {
			if (id == R.id.en_font)
			{
				current = 0;
			}
			else if (id == R.id.ch_font)
			{
				current = 1;
			}
			else if (id == R.id.khmer_font)
			{
				current = 2;
			}
			else if (id == R.id.korean_font)
			{
				current = 3;
			}
			else if (id == R.id.lao_font)
			{
				current = 4;
			}
			else if (id == R.id.mm_font)
			{
				current = 5;
			}
			else if (id == R.id.shan_font)
			{
				current = 6;
			}
			else if (id == R.id.tai_font)
			{
				current = 7;
			}
			else if (id == R.id.th_font)
			{
				current = 8;
			}
			else if (id == R.id.title_font)
			{
				current = 9;
			}

			refresh();
		}
	}
	
	@SuppressLint("SuspiciousIndentation")
	public void processJson(String inputJson){
		posts = new ArrayList<PostItem>();
		String input="";
		switch(currentFont){
			default:
				input=inputJson;
				break;
		}
		input=Html.fromHtml(input).toString();
		if(input.indexOf("<body>")>=0)
		input=input.substring(input.indexOf("<body>")+9);
		if(input.indexOf("</body>")>=0)
		input=input.substring(0,input.indexOf("</body>"));
		try
		{
			
					JSONObject obj=new JSONObject(input);
					JSONArray jarr=obj.getJSONArray("fonts");
					for(int j=0;j<jarr.length();j++){
						PostItem p=new PostItem();
						p.title=(jarr.getJSONObject(j).getString("title"));
						p.link=(jarr.getJSONObject(j).getString("link"));
						p.thumbnailUrl=(jarr.getJSONObject(j).getString("image"));
						p.desc=(jarr.getJSONObject(j).getString("desc"));
						addItem(p);
					}
		}
		catch (JSONException e)
		{
			//Toast.makeText(this,e.toString(),1).show();
		}
	}

	@Override
	public boolean useGridLayout()
	{
		return true;
	}

	@Override
	public String getFeedAddress()
	{
		setTitle(titles[current]);
		return links[current];
	}

	public void rate(){
		try {
			startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getPackageName())));
		} catch (android.content.ActivityNotFoundException anfe) {
			startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName())));
		}

	}
	public void MoreApp(String pub){
		try {
			startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=pub:"+ pub)));
		} catch (android.content.ActivityNotFoundException anfe) {
			startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/search?q=pub:"+ pub)));
		}

	}
}
